/*
 * mycode.h
 *
 *  Created on: Apr 13, 2021
 *      Author: admin
 */

#ifndef MYLED_H_
#define MYLED_H_

#include "main.h"

void LED_Bilink_Task(void);

#endif /* MYLED_H_ */
