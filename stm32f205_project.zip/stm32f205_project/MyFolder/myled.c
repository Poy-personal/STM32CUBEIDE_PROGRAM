/*
 * mycode.c
 *
 *  Created on: Apr 13, 2021
 *      Author: admin
 */
#include <myled.h>

void LED_Bilink_Task(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
	HAL_Delay(1000);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
	HAL_Delay(1000);
}
